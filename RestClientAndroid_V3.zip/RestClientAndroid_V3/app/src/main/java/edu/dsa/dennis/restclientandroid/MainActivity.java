package edu.dsa.dennis.restclientandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Retrofit;
//import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;



public class MainActivity extends AppCompatActivity {

    ArrayList<String> listDatos = new ArrayList<>();
    List<Repo> listRepos = new ArrayList<>();
    RecyclerView recycler;
    EditText userText;



  public void enviarPeticion(View view){
      userText= findViewById(R.id.userText);
        recycler = findViewById(R.id.recyclerId);
        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.github.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        // Crea una instancia de la interfaz GitHub
        GitHub github = retrofit.create(GitHub.class);

        //llamada a la API de forma asíncrona
        Call<List<Repo>> call = github.listRepos(userText.getText().toString());//String.valueOf(userText)
        call.enqueue(new retrofit2.Callback<List<Repo>>() {
            @Override
            public void onResponse(Call<List<Repo>> call, retrofit2.Response<List<Repo>> response) {
                listDatos.clear();
                if (response.isSuccessful() && response.body() != null) {

                    listRepos = response.body();  // Obtén la lista de repos desde la respuesta
                    // Añade los datos de los repos a la lista de Datos
                    for (Repo repo : listRepos) {
                        listDatos.add("id: " + repo.id +"\n"+ " name: " + repo.name+"\n" + " stars: " + repo.stargazers_count+"\n");
                    }



                }
                else
                    listDatos.add("Usuario de Git no encontrado");
                // Actualiza el adapter con los datos obtenidos
                AdapterDatos adapter = new AdapterDatos(listDatos);
                recycler.setAdapter(adapter);
            }

            @Override
            public void onFailure(Call<List<Repo>> call, Throwable t) {
                // Manejo de error en la llamada
                t.printStackTrace();
            }
        });

   }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

