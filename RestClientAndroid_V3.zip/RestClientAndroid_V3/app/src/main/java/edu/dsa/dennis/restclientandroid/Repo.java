package edu.dsa.dennis.restclientandroid;

public class Repo {
    public final String name;
    public final int stargazers_count;
    public final int id;

    public Repo(String name, int stargazers_count, int id) {
        this.name = name;
        this.stargazers_count = stargazers_count;
        this.id = id;
    }
}
